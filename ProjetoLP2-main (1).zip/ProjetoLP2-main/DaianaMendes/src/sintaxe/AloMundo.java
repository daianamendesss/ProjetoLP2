/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sintaxe;

/**
 *
 * @author 15385404608
 */
public class AloMundo {
    public static void main(String[] args){
    System.out.println("Alô Mundo...");
    String ano = args[0];
    String senha = args[1];
    String nome = args[2];
    
    System.out.println("Ano: "+ano);
    System.out.println("Senha: "+senha);  
    System.out.println("Nome: "+nome);
    
    
    
 
    }
    
}
